#!/bin/sh

cd ${HOME}/properties-editor
./killPropertiesEditor.sh
./runPropertiesEditor.sh &
