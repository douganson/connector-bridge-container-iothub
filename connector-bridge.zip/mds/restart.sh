#!/bin/sh

./kill-all.sh
sleep 5
./start-all.sh
